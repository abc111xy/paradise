// Import cetz into the root scope. Import cetz by importing this file only!
#import "../../../cetz/0.5.2/src/lib.typ": *
